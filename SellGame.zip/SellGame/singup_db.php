<?php
    session_start();
    require_once 'server/server.php';

    if (isset($_POST['sing_up'])){
        $name = $_POST['name'];
        $age = $_POST['age'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $username = $_POST['username'];
        $password =$_POST['password'];
        $password2 =$_POST['password2'];
        $bank =$_POST['bank'];
        $bank_number =$_POST['bank_number'];
        $urole ='user';

        if (empty($name)){
            $_SESSION['error'] = 'กรุณากรอกชื่อ';
            header("location:Form.php");
        }else if(empty($age)){
            $_SESSION['error'] = 'กรุณากรอกอายุ';
            header("location:Form.php");
        }else if(empty($email)){
            $_SESSION['error'] = 'กรุณากรอกอีเมล';
            header("location:Form.php");
        }else if(empty($phone)){
            $_SESSION['error'] = 'กรุณากรอกเบอร์โทร';
            header("location:Form.php");
        }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $_SESSION['error'] = 'รูปแบบอีเมลไม่ถูกต้อง';
            header("location:Form.php");
        }else if(empty($username)){
            $_SESSION['error'] = 'กรุณากรอก Username';
            header("location:Form.php");
        }else if(empty($password)){
            $_SESSION['error'] = 'กรุณากรอก password';
            header("location:Form.php");
        }else if(strlen($_POST['password'])>20 || strlen($_POST['password'])<5){
            $_SESSION['error'] = 'รหัสผ่านต้องมีความยาวระหว่าง 5-20 ตัวอักษร';
            header("location:Form.php");
        }else if(empty($password2)){
            $_SESSION['error'] = 'กรุณายืนยัน password';
            header("location:Form.php");
        }else if ($password != $password2){
            $_SESSION['error'] = 'password ไม่ตรงกัน';
            header("location:Form.php");
        }else if(empty($bank)){
            $_SESSION['error'] = 'กรุณาเลือก Bank';
            header("location:Form.php");
        }else if(empty($bank_number)){
            $_SESSION['error'] = 'กรุณากรอกหมายเลขบัญชีธนาคาร';
            header("location:Form.php");
        }else{
            // ... your code ...

try {
    $check_email = $conn->prepare("SELECT email FROM users WHERE email = :email");
    $check_email->bindParam(":email", $email);
    $check_email->execute();
    $row = $check_email->fetch(PDO::FETCH_ASSOC);

    if ($row !== false && $row['email'] == $email) {
        $_SESSION['warning'] = "มี Email นี้อยู่ในระบบแล้ว <a href='index.php'>คลิ๊กที่นี่เพื่อเข้าสู่ระบบ</a>";
        header("location:Form.php");
        exit; // Add this line to stop script execution after redirection
    } else if (!isset($_SESSION['error'])) {
        // rest of the code

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users(name,age,email,username,phone,password,bank,bank_number,urole) VALUES(:name,:age,:email,:username,:phone,:password,:bank,:bank_number,:urole)");
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":age", $age);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":phone", $phone);
        $stmt->bindParam(":password", $passwordHash);
        $stmt->bindParam(":bank", $bank);
        $stmt->bindParam(":bank_number", $bank_number);
        $stmt->bindParam(":urole", $urole);
        $stmt->execute();
        $_SESSION['success']="สมัครสมชิกเรียบร้อยแล้ว! <a href='index.php' class='alert-link'>คลิ๊กที่นี่เพื่อเข้าสู่ระบบ</a>";
        header("location:Form.php");
        exit; // Add this line to stop script execution after redirection
    } else {
        $_SESSION['error']="มีบางอย่างผิดพลาด";
        header("location:Form.php");
        exit; // Add this line to stop script execution after redirection
    }

// ... your code ...

} catch (PDOException $e) {
    echo $e->getMessage();
}

        }
    }
?>