<?php session_start(); ?>
<?php
include("head.php");
include("menu.php");
?> 
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
</head>
<body style="background-color:black;">
<div id="myCarousel" class="carousel slide mb-6" data-bs-ride="carousel">
    <div class="carousel-indicators">
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="bd-placeholder-img" src="images/peper.jpg" width="100%" height="100%" >
        <div class="container">
          <div class="carousel-caption text-start">
            <h1>บริการเติมเกมส์ออนไลน์สุดคุ้ม</h1>
            <p class="opacity-75">ด้วยระบบอัตโนมัติ ไอเทมเข้าไวปลอดภัย 100%</p>
            <p><a class="btn btn-lg btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#modalSignin"><i class="bi bi-messenger">สั่งซื้อทันที</a></p>
          </div>
        </div>
      </div>
  </div>
  <?php
include("Login.php");
include("footer.php");
?>
</body>