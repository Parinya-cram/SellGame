<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['admin_login'])) {
    header("location: admin_login.php");
    exit;
}

if (isset($_SESSION['admin_login'])) {
    $admin_id = $_SESSION['admin_login'];
    $stmt = $conn->query("SELECT * FROM admin WHERE id = $admin_id");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,450;0,180;0,300;0,400;0,450;0,600;0,700;0,800;1,450;1,180;1,300;1,400;1,450;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .background {
            /* ตั้งภาพพื้นหลัง */
            background-image: url('images/bg1.jpg ');
            
            /* ปรับขนาดของภาพให้เต็มหน้าจอ */
            background-size: cover;

            /* ไม่แสดงการเลื่อนหน้าจอ */
            overflow: hidden;
        }

        /* เพิ่มความกำกับในที่ของคุณ */
        .content {
            text-align: center;
            padding: 45px;
            color: white;
        }
    </style>
</head>
<body class="k2d-regular">
<?php include 'head_admin.php';
?>
        <div style="background-color: rgb(0, 44, 110);">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="#" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png" style="height:48px;white:100%;"></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="admin_dashbord.php" class="nav-link " style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
        <li class="nav-item"><a href="admin_add_game.php" class="nav-link "style="color:rgb(255, 255, 255); font-size:20px;">เพิ่มรายการเกมส์</a></li>
        <li class="nav-item"><a href="admin_regis_detail.php" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อลูกค้า</a></li>
        <li class="nav-item"><a href="admin_detail_topup.php" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อการเติมเงิน</a></li>
        <li class="nav-item"><a href="admin_topup.php" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อการเติมเกมส์</a></li>
        <li class="nav-item"><a href="admin_total.php" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">ยอดรวม</a></li>
      </ul>
    </header>
  </div>

  <body>
    <?php
  $id = null;
  if ( !empty($_GET['id'])) {
      $id = $_REQUEST['id'];
  }
    // Fetch user data based on the provided ID
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
  <div class="container">
            <div class="row">
                <h3>Edit Profile</h3>
            </div>
            <div class="row">
<div class="modal-content rounded-5 shadow">
		  <div id="myCard" class="card m-3" style="max-width: 100%;">
          <h1 class="k2d-semibold-italic"style="text-align: center;">แก้ไข User</h1>  
		  <form action="admin_regis_detail_edit_db.php" method="post">
      <?php if(isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger"role="alert">
                    <?php
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                    </div>
            <?php } ?>
            <?php if(isset($_SESSION['success'])) { ?>
            <div class="alert alert-success"role="alert">
                    <?php
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                    </div>
            <?php } ?>
      <div class="m-3">
			<label for="id"class="form-label">ID:</label>
			<input type="number" name="id" class="form-control" placeholder="" value="<?php echo $row['id']; ?>"readonly>
		  </div>
            <div class="m-3">
			<label for="name"class="form-label">Name:</label>
			<input type="text" name="name" class="form-control" placeholder="" value="<?php echo $row['name']; ?>">
		  </div>
		  <div class="m-3">
			<label for="age"class="form-label">Age:</label>
			<input type="age" name="age" class="form-control" placeholder=""value="<?php echo $row['age']; ?>">
		  </div>
		  <div class="m-3">
      <label for="phone" class="form-label">Phone Number:</label>
      <input type="number" name="phone" class="form-control" placeholder=""value="<?php echo $row['phone']; ?>">
      </div>
      <div class="m-3">
      <label for="username" class="form-label">Phone Number:</label>
      <input type="text" name="username" class="form-control" placeholder=""value="<?php echo $row['username']; ?>">
      </div>
      <div class="m-3">
		  <label for="password"class="form-label">Password:</label>
		  <input type="password" name="password" placeholder="" class="form-control">
		  </div>
          <div class="m-3">
		  <label for="password2"class="form-label">Confirm Password:</label>
		  <input type="password" name="password2" placeholder="" class="form-control">
		  </div>
		  <div class="m-3">
      <button type="submit" name="Update" value="Update"class="p-2 btn btn-primary">Update</button>
			<button type="reset" class="p-2 btn btn-secondary" style="background-color:Red;">Cancel</button>
			</div>
		  </div>
		  <div>
		  </div>
		  </form>
</div>
</div>
</html>