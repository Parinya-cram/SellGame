<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['admin_login'])) {
    header("location: admin_login.php");
    exit;
}

if (isset($_SESSION['admin_login'])) {
    $admin_id = $_SESSION['admin_login'];
    $stmt = $conn->query("SELECT * FROM admin WHERE id = $admin_id");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (isset($_SESSION['id'])) {
  $admin_id = $_SESSION['id'];
  $stmt = $conn->query("SELECT * FROM topup WHERE id = $admin_id");
  $stmt->execute();
  $topup = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preadmin_topup" href="https://fonts.googleapis.com">
    <link rel="preadmin_topup" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,450;0,180;0,300;0,400;0,450;0,600;0,700;0,800;1,450;1,180;1,300;1,400;1,450;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="aurlonymous">
    <link rel="stylesheet" type="text/css" href="./css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
    .background {
        /* ตั้งภาพพื้นหลัง */
        background-image: url('images/bg1.jpg ');

        /* ปรับขนาดของภาพให้เต็มหน้าจอ */
        background-size: cover;

        /* ไม่แสดงการเลื่อนหน้าจอ */
        overflow: hidden;
    }

    /* เพิ่มความกำกับในที่ของคุณ */
    .content {
        text-align: center;
        padding: 45px;
        color: white;
    }
    </style>
</head>

<body class="k2d-regular">
    <?php include 'head_admin.php';
?>
    <div style="background-color: rgb(0, 44, 110);">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
            <a href="#"
                class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-urlone">
                <svg class="bi me-2" width="40" height="32">
                    <use xlink:href="#bootstrap"></use>
                </svg>
                <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png"
                        style="height:48px;white:100%;"></span>
            </a>

            <ul class="nav nav-pills">
                <li class="nav-item"><a href="admin_dashbord.php" class="nav-link "
                        style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
                        <li class="nav-item"><a href="admin_add_game.php" class="nav-link "
                        style="color:rgb(255, 255, 255); font-size:20px;">เพิ่มรายการเกมส์</a></li>
                <li class="nav-item"><a href="admin_regis_detail.php" class="nav-link"
                        style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อลูกค้า</a></li>
                <li class="nav-item"><a href="admin_detail_topup.php" class="nav-link"
                        style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อการเติมเงิน</a></li>
                <li class="nav-item"><a href="admin_detail_buy_game.php" class="nav-link"
                        style="color:rgb(255, 255, 255);font-size:20px;">รายชื่อการเติมเกมส์</a></li>
                <li class="nav-item"><a href="admin_total.php" class="nav-link"
                        style="color:rgb(255, 255, 255);font-size:20px;">ยอดรวม</a></li>
            </ul>
        </header>
    </div>

    </header>
    <div class="background">
    </div>

    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-7"> <br>
                    <h3>PHP PDO Basic Upload Image File</h3>
                    <form action="admin_topup_db.php" method="post" enctype="multipart/form-data">
                        <input type="text" name="img_name" required class="form-control" placeholder="ชื่อภาพ"> <br>
                        <b style="color:red;">*อัพโหลดได้เฉพาะ .jpeg , .jpg , .png </b>
                        <input type="file" name="image" required class="form-control"
                            accept="image/jpeg, image/png, image/jpg"> <br>
                        <input type="text" name="price" required class="form-control" placeholder="ราคา"> <br>
                        <lable for="admin_bank" class="form-label">Bank:</lable><br>
                        <select name="admin_bank" id="admin_bank" class="form-control">
                            <option value="ธนาคารกรุงเทพ">ธนาคารกรุงเทพ</option>
                            <option value="ธนาคารกสิกรไทย">ธนาคารกสิกรไทย</option>
                            <option value="ธนาคารกรุงไทย">ธนาคารกรุงไทย</option>
                            <option value="ธนาคารไทยพาณิชย์">ธนาคารไทยพาณิชย์</option>
                        </select>
                        <label for="admin_bank_number" class="form-label">Bank Number:</label><br>
                        <input type="text" name="admin_bank_number" class="form-control"
                            placeholder="XXXX-XXXX-XXXX-X"><br>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </form>
                    <h3>รายการภาพ </h3>
                    <table class="table table-striped  table-hover table-responsive table-bordered">
                        <thead>
                            <tr>
                                <th width="5%">สถานะ</th>
                                <th width="65%">ชื่อภาพ</th>
                                <th width="30%">ภาพ</th>
                                <th width="30%">ธนาคาร</th>
                                <th width="30%">หมายเลขบัญชี</th>
                                <th width="30%">จำนวนเงิน</th>
                                <th width="30%">ลบข้อมูล</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Query data to display in the table
                            require_once 'admin_topup.php';
                            $stmt = $conn->prepare("SELECT * FROM topup ");
                            $stmt->execute();
                            $result = $stmt->fetchAll();

                            foreach ($result as $k) {
                            ?>
                            <tr>
                                <td><?= $k['id']; ?></td>
                                <td><?= $k['img_name']; ?></td>
                                <td><img src="./images/<?= $k['image']; ?>" width="70px"></td>
                                <td><?= $k['admin_bank']; ?></td>
                                <td><?= $k['admin_bank_number']; ?></td>
                                <td><?= $k['price']; ?> ฿</td>
                                <td>
                                    <!-- Delete button for each row -->
                                    <a class="btn btn-danger" href="admin_topup.php?delete_id=<?= $k['id']; ?>"
                                        onclick="return confirm('Are you sure you want to delete?')">Delete</a>
                                    <?php
@session_start();
require_once 'server/server.php';

if (!isset($_SESSION['admin_login'])) {
    header("location: index.php");
    exit;
}

// Check if delete_id is set in the URL
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    // Perform deletion based on the provided ID
    $stmt_delete = $conn->prepare("DELETE FROM topup WHERE id = :delete_id");
    $stmt_delete->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $result_delete = $stmt_delete->execute();

    // Check if deletion was successful
    
    if ($result_delete) {
        echo '<script>
             setTimeout(function() {
              swal({
                  title: "Record deleted successfully",
                  type: "success"
              }, function() {
                  window.location = "admin_topup.php"; // Redirect to the same page
              });
            }, 1000);
        </script>';
    } else {
        echo '<script>
             setTimeout(function() {
              swal({
                  title: "Failed to delete record",
                  type: "error"
              }, function() {
                  window.location = "admin_topup.php"; // Redirect to the same page
              });
            }, 1000);
        </script>';
    }
}
if (isset($_POST['id_order'])) {
    $id_order = (int)$_POST['id_order']; // Cast to integer for validation

    // Check if user exists with prepared statement (prevents SQL injection)
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id_order");
    $stmt->bindParam(':id_order', $id_order, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user) {
        // User exists, proceed with top-up insertion
        // ... (your existing topup insert code)
    } else {
        echo '<script>
            setTimeout(function() {
                swal({
                    title: "ไม่พบรหัสลูกค้า",
                    type: "error"
                }, function() {
                    window.location = "admin_topup.php";
                });
            }, 1000);
        </script>';
    }
}

// Rest of your existing code goes here
?>
                                </td>
                            </tr>

                            <?php } ?>
                        </tbody>
                    </table>
                    <br>
                </div>
            </div>
        </div>
    </body>

</html>