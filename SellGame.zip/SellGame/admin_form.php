<?php 
session_start();
require_once 'server/server.php'
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
  <div class="modal-content rounded-5 shadow">
		  <div id="myCard" class="card m-3" style="max-width: 100%;">
          <h1 class="k2d-semibold-italic"style="text-align: center;">ลงทะเบียน Admin</h1>  
		  <form action="admin_singup_db.php" method="post">
		  <?php if(isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger"role="alert">
                    <?php
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                    </div>
            <?php } ?>
            <?php if(isset($_SESSION['success'])) { ?>
            <div class="alert alert-success"role="alert">
                    <?php
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                    </div>
            <?php } ?>
            <?php if(isset($_SESSION['warning'])) { ?>
                <div class="alert alert-warning" role="alert">
                    <?php
                        echo $_SESSION['warning'];
                        unset($_SESSION['warning']);
                    ?>
                    </div>
            <?php } ?>
		  <div class="m-3">
			<label for="admin_name"class="form-label">Name:</label>
			<input type="text" name="admin_name" class="form-control" placeholder="Name">
		  </div>
		  <div class="m-3">
			<label for="admin_age"class="form-label">Age:</label>
			<input type="age" name="admin_age" class="form-control" placeholder="Age">
		  </div>
		  <div class="m-3">
		<label for="admin_email"class="form-label">Email:</label>
		<input type="email" name="admin_email" placeholder="name@gmail.com" class="form-control">
		  </div>
		  <div class="m-3">
      <label for="admin_phone" class="form-label">Phone Number:</label>
      <input type="number" name="admin_phone" class="form-control" placeholder="08X-XXX-XXXX">
      </div>
      <div class="m-3">
		<label for="password"class="form-label">Password:</label>
		<input type="password" name="password" placeholder="*********" class="form-control">
		  </div>
          <div class="m-3">
		<label for="password2"class="form-label">Confirm Password:</label>
		<input type="password" name="password2" placeholder="*********" class="form-control">
		  </div>
      <div class="m-3">
      <lable for="admin_bank"class="form-label">admin_Bank:</lable>
      <select name="admin_bank" id="admin_bank"class="form-control">
      <option value="ธนาคารกรุงเทพ">ธนาคารกรุงเทพ</option>
      <option value="ธนาคารกสิกรไทย">ธนาคารกสิกรไทย</option>
      <option value="ธนาคารกรุงไทย">ธนาคารกรุงไทย</option>
      <option value="ธนาคารไทยพาณิชย์">ธนาคารไทยพาณิชย์</option>
      </select>
      </div>
      <div class="m-3">
      <label for="admin_bank_number" class="form-label">admin_Bank Number:</label>
      <input type="number" name="admin_bank_number" class="form-control" placeholder="XXXX-XXXX-XXXX-X">
      </div>
		  <div class="m-3">
			<button type="submit" name="admin_sing_up" class="p-2 btn btn-primary">Confirm</button>
			<button type="reset" class="p-2 btn btn-secondary" style="background-color:Red;">Cancel</button>
			</div>
            <a href="admin_login.php" class="m-3 p-2 btn btn-success"><i class="bi bi-arrow-left-circle-fill"></i>Home</a>
		  </div>
		  <div>
		  </div>
		  </form>
</div>
</div>

</html>