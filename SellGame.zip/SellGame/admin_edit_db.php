<?php
session_start();
require_once 'server/server.php';

try {
    // Fetch user data based on the provided ID
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM admin WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle database error gracefully (consider redirecting to an error padmin_age)
    echo "Error fetching user data: " . $e->getMessage();
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Keep track of post values
    $id = $_POST['id'];
    $admin_name = $_POST['admin_name'];
    $admin_age = $_POST['admin_age'];
    $admin_phone = $_POST['admin_phone'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    if (empty($admin_name)){
        $_SESSION['error'] = 'กรุณากรอกชื่อ';
        header("location:admin_edit.php");
    }else if(empty($admin_age)){
        $_SESSION['error'] = 'กรุณากรอกอายุ';
        header("location:admin_edit.php");
    }else if(empty($admin_phone)){
        $_SESSION['error'] = 'กรุณากรอกเบอร์โทร';
        header("location:admin_edit.php");
    }else if(empty($password)){
        $_SESSION['error'] = 'กรุณากรอก password';
        header("location:admin_edit.php");
    }else if(strlen($_POST['password'])>20 || strlen($_POST['password'])<5){
        $_SESSION['error'] = 'รหัสผ่านต้องมีความยาวระหว่าง 5-20 ตัวอักษร';
        header("location:admin_edit.php");
    }else if(empty($password2)){
        $_SESSION['error'] = 'กรุณายืนยัน password';
        header("location:admin_edit.php");
    }else if ($password != $password2){
        $_SESSION['error'] = 'password ไม่ตรงกัน';
        header("location:admin_edit.php");
    }else{


    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Set PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Use placeholders in the UPDATE query
        $stmt = "UPDATE admin SET admin_name =?, admin_age =?, admin_phone =?,  password=? WHERE id=?";
        $q = $conn->prepare($stmt);
        $q->execute([$admin_name, $admin_age, $admin_phone,$passwordHash, $id]);

        // Redirect after successful update
        header("Location: admin_regis_detail.php");
        exit;
    } catch (PDOException $e) {
        // Handle database error gracefully (consider redirecting to an error padmin_age)
        echo "Error updating user data: " . $e->getMessage();
        exit;
    }
}
}
?>
