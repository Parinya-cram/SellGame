<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['user_login'])) {
    header("location: index.php");
    exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['order_id'])) {
        // Get the product ID from the form
        $productId = $_POST['order_id'];

        // Retrieve the product details based on the product ID
        $stmt = $conn->prepare("SELECT * FROM order_game WHERE order_name = :productName");
        $stmt->bindParam(':productName', $productId, PDO::PARAM_STR);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        // Insert the order into the database (you may need to adjust this part based on your database schema)
        $userId = $_SESSION['user_login'];
        $stmt = $conn->prepare("INSERT INTO order_game (id, order_id, order_date) VALUES (:userId, :productId, NOW())");
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':productId', $product['id'], PDO::PARAM_INT);
        $stmt->execute();

        // Display the order confirmation message
        $orderMessage = "Your order for {$product['order_name']} has been placed successfully!";
    }
}

if (isset($_SESSION['user_login'])) {
    $user_id = $_SESSION['user_login'];
    $stmt = $conn->query("SELECT * FROM users where id = $user_id");
    $result = $stmt->fetch();
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
    $stmt = $conn->query("SELECT u.user_price, SUM(t.price) AS total_price FROM users u JOIN user_topup t ON u.bank_number = t.user_bank_number GROUP BY u.id");
    $result = $stmt->fetch();
    $stmt->execute();
    $t = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,450;0,180;0,300;0,400;0,450;0,600;0,700;0,800;1,450;1,180;1,300;1,400;1,450;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/font.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .background {
            /* ตั้งภาพพื้นหลัง */
            background-image: url('./images/gb.jpg');
            
            /* ปรับขนาดของภาพให้เต็มหน้าจอ */
            background-size: cover;

            /* ไม่แสดงการเลื่อนหน้าจอ */
            overflow: hidden;
        }

        /* เพิ่มความกำกับในที่ของคุณ */
        .content {
            text-align: center;
            padding: 45px;
            color: white;
        }
    </style>
</head>
<?php include 'head_user.php'; ?>

   
        <div style="background-color: rgb(0, 44, 110);">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="user_dash.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png" style="height:48px;white:100%;"></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="user_dash.php" class="nav-link " style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เกี่ยวกับเรา</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เติมเกมส์ออนไลน์</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">คำถามที่พบบ่อย</a></li>
      </ul>
    </header>
  </div>
    </header>
<body>
<div class="background">
<div class="container" style="color:white; background-color:rgb(0, 63, 158);">
  <main>
    <?php
            $stmt = $conn->prepare("SELECT * FROM order_game where id = 1");
            $stmt->execute();
            $result = $stmt->fetchAll();
            foreach ($result as $k) {
            ?>
            <?php }?>
    <?php
    // Display order confirmation message if set
    if (isset($orderMessage)) {
        echo "<p>{$orderMessage}</p>";
    }
    ?>
<div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Bill</span>
          <span class="badge bg-primary rounded-pill"><?=$k['id'];?></span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">NAME</h6>
              <small class="text-body-secondary"><input type="text" class="form-control" id="lastName" placeholder="" value="<?=$row['name'];?>" required></small>
            </div>
          
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Email:</h6>
              <small class="text-body-secondary"><input type="email" class="form-control" id="email" placeholder="" value="<?=$row['email'];?>" required></small>
            </div>
           
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Username:</h6>
              <small class="text-body-secondary"><input type="text" class="form-control" id="username" placeholder="" value="<?=$row['username'];?>" required></small>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between bg-body-tertiary">
            <div class="text-success">
              <h6 class="my-0">Price:</h6>
              <small><input type="number" class="form-control" id="price" placeholder="" value="<?=$k['price'];?>" required></small>
            </div>
          </li>
          <h6 class="my-0">Total:</h6>
          <li class="list-group-item d-flex justify-content-between">
            <span><input type="number" class="form-control" id="total_price" placeholder="" value="<?=$t['total_price'];?>" required></span>
          </li>
        </ul>


      </div>
      <div class="col-md-7 col-lg-8">
        
        <h2 class="mb-3">Genshin Impack</h2>
        <img src="./images/<?= $k['order_img']; ?>" width="150px">

          <div class="row g-3">
            <div class="col-sm-6">


              <div class="invalid-feedback">
                Valid first name is required.
              </div>
            </div>


              
              <div class="invalid-feedback">
                Valid last name is required.
              </div>
            </div>



          <div class="row gy-3">
            <div class="col-md-6">
              <label for="ID_Game" class="form-label">ID:Genshin Impack</label>
              <input type="text" class="form-control" id="ID_Game" placeholder="ID" required="">
              <small class="text-body-secondary">Full name as displayed on card</small>
              <div class="invalid-feedback">
                Name on card is required
              </div>
            </div>

            <div class="col-md-5">
              <label for="server" class="form-label">Server:</label>
              <select class="form-select" id="server" required>
                <option value="server">SERVER</option>
                <option>Asia Server</option>
                <option>America Server</option>
                <option>Europe Server</option>
                <option>TW,HK,MO Server</option>
              </select>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>


            

            <div class="row mb-3 text-center" >
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g2.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g3.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g4.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
     </div>
      <div class="row mb-3 text-center" >
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g4.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g4.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g4.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
      </div>
      <div class="row mb-3 text-center" >
      <div class="col-4 themed-grid-col">
        <button class="btn btn-light">
      <img src="./images/g4.png" alt="">
      <b >พรแห่งดวงจันทร์ <?=$k['price']?> ฿</b>
      </button>
      </div>
    </div>
</div>
          <button class="w-100 btn btn-primary btn-lg" type="submit">Continue to checkout</button>
        </form>
      </div>
    </div>
  </main>

  <footer class="my-5 pt-5 text-body-secondary text-center text-small">
    <p class="mb-1">© 2017–2024 Company Name</p>
    <ul class="list-inline">
      <li class="list-inline-item"><a href="#">Privacy</a></li>
      <li class="list-inline-item"><a href="#">Terms</a></li>
      <li class="list-inline-item"><a href="#">Support</a></li>
    </ul>
  </footer>
</div>
    <a class="btn btn-primary" href="user_dash.php">Back to Home</a>
    </div>
</div>
</body>
</html>