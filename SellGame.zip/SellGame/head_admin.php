<body class="k2d-regular">
<header>
    <div class="top-background" style="height: 10%;">
        <b class="time">เวลาทำการ 10:00-00:00</b>
        <div class="dropdown text-end">
        <a href="admin_dashbord.php" id="dropdownBtn" style="color:black;" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="true">
    <img src="./images/user.png" alt="mdo" width="32" height="32" class="rounded-circle"><?php echo '<b style="color:white;">' . $row['admin_name'] . '</b>';?>
        </a><script>
    document.addEventListener('DOMContentLoaded', function () {
        var dropdownBtn = document.getElementById('dropdownBtn');
        
        dropdownBtn.addEventListener('click', function () {
            var dropdownMenu = document.querySelector('.dropdown-menu');
            
            if (dropdownMenu.style.display === 'block') {
                dropdownMenu.style.display = 'none';
            } else {
                dropdownMenu.style.display = 'block';
            }
        });
    });
</script>
          <ul class="dropdown-menu dropdown-menu-end"style="color:Red;background-color:rgb(0, 43, 107);"  data-popper-placement="bottom-start">
            <li><a class="dropdown-item"style="color:green;" href="admin_topup.php">หน้า Topup</a></li>
<?php echo '<li><a class="dropdown-item"style="color:green;" href="admin_edit.php?id=' . $row['id'] . '">ตั้งค่าโปรไฟล์</a></li>' ?>
            <li><a class="dropdown-item"style="color:green;" href="admin_profile.php">โปรไฟล์</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item"style="color:red;" type="buttom"href="Logout.php">Sign out</a></li>
          </ul>
        </div>
       