<?php
session_start();
require_once 'server/server.php';

if (isset($_POST['admin_sing_up'])) {
    $admin_name = $_POST['admin_name'];
    $admin_age = $_POST['admin_age'];
    $admin_email = $_POST['admin_email'];
    $admin_phone = $_POST['admin_phone'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $admin_bank = $_POST['admin_bank'];
    $admin_bank_number = $_POST['admin_bank_number'];
    $urole = 'admin';

    if (empty($admin_name)) {
        $_SESSION['error'] = 'กรุณากรอกชื่อ';
        header("location:admin_form.php");
    } else if (empty($admin_age)) {
        $_SESSION['error'] = 'กรุณากรอกอายุ';
        header("location:admin_form.php");
    } else if (empty($admin_email)) {
        $_SESSION['error'] = 'กรุณากรอกอีเมล';
        header("location:admin_form.php");
    } else if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'รูปแบบอีเมลไม่ถูกต้อง';
        header("location:Form.php");
    } else if (empty($admin_phone)) {
        $_SESSION['error'] = 'กรุณากรอกเบอร์โทร';
        header("location:admin_form.php");
    } else if (empty($password)) {
        $_SESSION['error'] = 'กรุณากรอก password';
        header("location:admin_form.php");
    } else if (strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5) {
        $_SESSION['error'] = 'รหัสผ่านต้องมีความยาวระหว่าง 5-20 ตัวอักษร';
        header("location:admin_form.php");
    } else if (empty($password2)) {
        $_SESSION['error'] = 'กรุณายืนยัน password';
        header("location:admin_form.php");
    } else if ($password != $password2) {
        $_SESSION['error'] = 'password ไม่ตรงกัน';
        header("location:admin_form.php");
    } else if (empty($admin_bank)) {
        $_SESSION['error'] = 'กรุณาเลือก admin_Bank';
        header("location:admin_form.php");
    } else if (empty($admin_bank_number)) {
        $_SESSION['error'] = 'กรุณากรอกหมายเลขบัญชีธนาคาร';
        header("location:admin_form.php");
    } else {
        // ... your code ...

        try {
            $check_admin_name = $conn->prepare("SELECT admin_name FROM admin WHERE admin_name = :admin_name");
            $check_admin_name->bindParam(":admin_name", $admin_name);
            $check_admin_name->execute();
            $row = $check_admin_name->fetch(PDO::FETCH_ASSOC);

            if ($row !== false && $row['admin_name'] == $admin_name) {
                $_SESSION['warning'] = "มี *ชื่อ* นี้อยู่ในระบบแล้ว <a href='admin_login.php'>คลิ๊กที่นี่เพื่อเข้าสู่ระบบ</a>";
                header("location:admin_form.php");
                exit; // Add this line to stop script execution after redirection
            } else if (!isset($_SESSION['error'])) {
                // rest of the code

                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO admin(admin_name,admin_age,admin_email,admin_phone,password,admin_bank,admin_bank_number,urole) VALUES(:admin_name,:admin_age,:admin_email,:admin_phone,:password,:admin_bank,:admin_bank_number,:urole)");
                $stmt->bindParam(":admin_name", $admin_name);
                $stmt->bindParam(":admin_age", $admin_age);
                $stmt->bindParam(":admin_email", $admin_email);
                $stmt->bindParam(":admin_phone", $admin_phone);
                $stmt->bindParam(":password", $passwordHash);
                $stmt->bindParam(":admin_bank", $admin_bank);
                $stmt->bindParam(":admin_bank_number", $admin_bank_number);
                $stmt->bindParam(":urole", $urole);
                $stmt->execute();
                $_SESSION['success'] = "สมัครสมชิกเรียบร้อยแล้ว! <a href='admin_login.php' class='alert-link'>คลิ๊กที่นี่เพื่อเข้าสู่ระบบ</a>";
                header("location:admin_form.php");
                exit; // Add this line to stop script execution after redirection
            } else {
                $_SESSION['error'] = "มีบางอย่างผิดพลาด";
                header("location:admin_form.php");
                exit; // Add this line to stop script execution after redirection
            }

            // ... your code ...

        } catch (PDOException $e) {
            echo $e->getMessage();
        }

    }
}
?>