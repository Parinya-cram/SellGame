<body class=".k2d-semibold-italic">
<div style="background-color: rgb(0, 44, 110);">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="#" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png" style="height:48px;white:100%;"></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="index.php" class="nav-link " style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เกี่ยวกับเรา</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เติมเกมส์ออนไลน์</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">คำถามที่พบบ่อย</a></li>
      </ul>
    </header>
  </div>
</body>