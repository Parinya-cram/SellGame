<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['admin_login'])) {
    header("location: index.php");
    exit;
}

if (isset($_SESSION['admin_login'])) {
    $admin_id = $_SESSION['admin_login'];
    $stmt = $conn->query("SELECT * FROM users WHERE id = $admin_id");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (isset($_POST['updateAmount'])) {
    try {
        // Get data from form
        $id = $_POST['id'];
        $value = $_POST['price'];

        // Prepare update statement
        $stmt = $conn->prepare("UPDATE user_topup t JOIN users u ON u.bank_number = t.user_bank_number SET t.price = :price, u.user_price = :user_price WHERE t.user_id = u.id AND t.id = :id");

        $stmt->bindParam(':price', $value, PDO::PARAM_INT);
        $stmt->bindParam(':user_price', $value, PDO::PARAM_INT);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        // Execute update
        $stmt->execute();

        // Success message (optional)
        header( "location: admin_detail_topup.php");

        // Redirect back (optional)
        // header("Location: admin_detail_topup.php");

    } catch (PDOException $e) {
        echo "Error updating price: " . $e->getMessage();
    }
}
?>
