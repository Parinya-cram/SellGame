<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['user_login'])) {
    header("location: index.php");
    exit;
}

if (isset($_SESSION['user_login'])) {
    $user_id = $_SESSION['user_login'];
    $stmt = $conn->query("SELECT * FROM users where id = $user_id");
    $result = $stmt->fetch();
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,450;0,180;0,300;0,400;0,450;0,600;0,700;0,800;1,450;1,180;1,300;1,400;1,450;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .background {
            /* ตั้งภาพพื้นหลัง */
            background-color: aquamarine;
            
            /* ปรับขนาดของภาพให้เต็มหน้าจอ */
            background-size: cover;

            /* ไม่แสดงการเลื่อนหน้าจอ */
            overflow: hidden;
        }

        /* เพิ่มความกำกับในที่ของคุณ */
        .content {
            text-align: center;
            padding: 45px;
            color: white;
        }
    </style>
</head>
<?php include 'head_user.php'; ?>
   
        <div style="background-color: rgb(0, 44, 110);">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="#" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png" style="height:48px;white:100%;"></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="user_dash.php" class="nav-link " style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เกี่ยวกับเรา</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เติมเกมส์ออนไลน์</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">คำถามที่พบบ่อย</a></li>
      </ul>
    </header>
  </div>
    </header>
    <div class="background">
    <div class="container">
    <div class="row"style="backgrund-color:rgb(0, 95, 158);">
        <?php
            $stmt = $conn->prepare("SELECT * FROM order_game ");
            $stmt->execute();
            $result = $stmt->fetchAll();

            foreach ($result as $k) {
            ?>
        <div class="col-md-2" style="text-align: center;">
        <table>
            <img src="./images/<?= $k['order_img']; ?>" width="150px">
                <p><?= $k['order_name']; ?></p>  
            </table>            
        </div>
                    <?php
                 }?>
                 </div>
                 </div>
                </div>
                <script>
                    const imageFrames = document.querySelectorAll(".image-frame");

imageFrames.forEach((frame) => {
  frame.addEventListener("mouseenter", () => {
    frame.classList.add("hover");
  });

  frame.addEventListener("mouseleave", () => {
    frame.classList.remove("hover");
  });
});
</script>

<div style="float: left;margin:10px;"><a href="./TopUp/Genshin.php" tital="Genshin Impact">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="./images/<?php $k['order_img']; ?>" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Genshin Impact</p>
        </a>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/202312211644460marvel-snap.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Marvel Snap</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/202312211648097MU-archangel.png" width="215px" height="215px" > 
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">MU Archangel</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/2022112806484218_tower_of_fantasy_appicon.jpg " width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Tower of Fantasy</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/20221128063519588_legends_of_runeterra_appicon.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Legends of Runeterra</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/20221128063519588_nikke_appicon.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">GODDESS OF VICTORY: NIKKE</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/20221128063519588_x_hero_appicon.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">X-Hero</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/aceracer.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Ace Racer</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/Arena.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Arena Breakout</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/black.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Black Clover M</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/blood-strike.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Blood Strike</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/brawl-stars.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Brawl Stars</p>
    </div>
    </tr><tr>   
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/clash-of-clans.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Clash of Clans (SEA)</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/diablo-immortal.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Diablo: Immortal</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/dragon.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Dragon Raja</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/eggy-party.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Eggy Party</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/FCm.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">FC Mobile (FIFA Mobile)</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/freefire.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Free Fire</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/GRN.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Garena Shells</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/harry.png " width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Harry Potter: Magic Awakened</p>
    </div>
 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/honkai.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Honkai: Star Rail</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/hyper_front_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Hyper Front</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/identity.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Identity V</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/League.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">League of Legends (PC)</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/lol_wild_rift_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">League of legends: Wild Rift</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/maplestory-r-evolution.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">MapleStory R: Evolution</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/metal.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Metal Slug: Awakening</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/mobilelegends.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Mobile Legends: Bang Bang</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/mu_origin3_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">MU Origin 3 (SEA)</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/one-punch-man-the-strongest.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">ONE PUNCH MAN: The Strongest</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/onmyoji-arena.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Onmyoji Arena</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/rov.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">ROV</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/pubgm.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">PUBG Mobile (TH)</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/pubgmG.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">PUBG Mobile (Global)</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/rag-origin.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Ragnarok Origin</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/seal-mobile.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Seal Mobile</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/ragnarok.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Ragnarok X: Next Generation</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/razer_gold_pin.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">ฝากชำระเงินด้วยลิ้งค์ Razer Gold</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/sausage_man_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Sausage man</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/ragnarok_m_eternal_love_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Ragnarok M: Eternal Love Big Ca..</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/state-of-survival.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">State of Survival</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/super_sus_logo.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Super Sus</p>
    </div>
    </tr><tr> 
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/TeamFihgt.jpg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Teamfight Tactics Mobile</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/undawn.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Garena Undawn</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/valorant.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Valorant</p>
    </div>

    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/zepeto_logo.jpeg" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Zepeto</p>
    </div>
        
    <div style="float: left;margin:10px;">
        <img style="border-radius: 25px;border: 1px solid Red;border-radius: 10px;" src="images/hay-day.png" width="215px" height="215px" >
        <p style="color: rgb(255, 255, 255);text-align: center; background-color:rgb(130, 6, 168);border-radius: 50px;font-size: 14px;">Hay Day (SEA)</p>
    </div>