<?php
    session_start();
    require_once 'server/server.php';

    if (isset($_POST['admin_sing_in'])){
        $admin_name = $_POST['admin_name'];
        $password =$_POST['password'];

        if (empty($admin_name)){
            $_SESSION['error'] = 'กรุณากรอกอีเมล';
            header("location:admin_login.php");
        }  else if(empty($password)){
            $_SESSION['error'] = 'กรุณากรอก password';
            header("location:admin_login.php");
        } else if(strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5){
            $_SESSION['error'] = 'รหัสผ่านต้องมีความยาวระหว่าง 5-20 ตัวอักษร';
            header("location:admin_login.php");
        } else {
            try {
                $check_data = $conn->prepare("SELECT id, admin_name, password, urole FROM admin WHERE admin_name = :admin_name");
                $check_data->bindParam(":admin_name", $admin_name);
                $check_data->execute();
                $row = $check_data->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    if (password_verify($password, $row['password'])) {
                        if ($row['urole'] == 'admin') {
                            $_SESSION['admin_login'] = $row['id'];
                            header("location: admin_dashbord.php");
                        } else {
                            $_SESSION['user_login'] = $row['id'];
                            header("location: user_dash.php");
                        }
                    } else {
                        $_SESSION['error'] = 'รหัสผ่านผิด';
                        header("location: admin_login.php");
                    }
                } else {
                    $_SESSION['error'] = 'อีเมลผิด';
                    header("location: admin_login.php");
                }
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
    }
?>
