-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2024 at 06:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_age` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin_bank` varchar(255) NOT NULL,
  `admin_bank_number` varchar(255) NOT NULL,
  `urole` varchar(255) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `admin_age`, `admin_email`, `admin_phone`, `password`, `admin_bank`, `admin_bank_number`, `urole`, `create_at`) VALUES
(1, 'admin_01', '22', 'cramza556@gmail.com', '0902622420', '$2y$10$wC1D95VEh6OHpOafEWDZFuBNPXPVcAP5ad3GMFZtTW8A9CLPmO2nm', 'ธนาคารกสิกรไทย', '1323849028', 'admin', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(11) NOT NULL,
  `bill_admin` varchar(255) NOT NULL,
  `bill_user` varchar(255) NOT NULL,
  `bill_price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `bill_total` decimal(8,2) NOT NULL DEFAULT 0.00,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_game`
--

CREATE TABLE `order_game` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_name` varchar(255) NOT NULL,
  `order_img` varchar(255) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_total` decimal(8,2) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `server` varchar(255) NOT NULL,
  `ID_Game` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `order_game`
--

INSERT INTO `order_game` (`id`, `order_id`, `order_name`, `order_img`, `order_date`, `order_total`, `price`, `server`, `ID_Game`) VALUES
(1, 0, 'Genshin Impact', '67244295120240310_170225.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(2, 0, 'Marvel Snap', '115656990520240310_174100.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(3, 0, 'MU Archangel', '153631753820240310_174632.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(4, 0, 'Tower of Fantasy', '20824049020240310_174700.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(5, 0, 'Legends of Runeterra', '153579435420240310_174726.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(6, 0, 'GODDESS OF VICTORY: NIKKE', '31344621920240310_175158.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(7, 0, 'X-Hero', '145663524820240310_175213.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(8, 0, 'Ace Racer', '78068296320240310_175241.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(9, 0, 'Arena Breakout', '138742113520240310_175250.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(10, 0, 'Black Clover M', '79583363820240310_175306.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(11, 0, 'Blood Strike', '180000712020240310_175318.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(12, 0, 'Brawl Stars', '138682240120240310_175329.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(13, 0, 'Clash of Clans (SEA)', '172410710720240310_175346.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(14, 0, 'Diablo: Immortal', '30191495520240310_175358.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(15, 0, 'Dragon Raja', '106481605920240310_175408.jpg', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(16, 0, 'Eggy Party', '208572702320240310_175513.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(17, 0, 'FC Mobile (FIFA Mobile)', '135544690720240310_175522.png', '0000-00-00 00:00:00', 0.00, 0.00, '', ''),
(18, 0, 'Free Fire', '103938164120240310_175536.png', '0000-00-00 00:00:00', 0.00, 0.00, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `topup`
--

CREATE TABLE `topup` (
  `urlo` varchar(255) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `admin_bank` varchar(255) NOT NULL,
  `admin_bank_number` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `id` int(10) NOT NULL,
  `id_order` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `topup`
--

INSERT INTO `topup` (`urlo`, `img_name`, `image`, `admin_bank`, `admin_bank_number`, `price`, `id`, `id_order`) VALUES
('admin', 'QR', '25654516620240311_121831.jpg', 'ธนาคารกสิกรไทย', '1323849028', 0.00, 41, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `bank_number` varchar(255) DEFAULT NULL,
  `urole` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `total_price` decimal(8,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `age`, `email`, `phone`, `username`, `password`, `bank`, `bank_number`, `urole`, `create_at`, `user_price`, `total_price`) VALUES
(4, 'Parinya Pathumthong', '22', 'cramza556@gmail.com', '0902622420', 'PPC_Room', '$2y$10$x5Uwq2gb255OtlaW6NczhOjYtAgXqmiUZ0AO55pv2w00kHT.AB3ji', 'ธนาคารกสิกรไทย', '1323849028', 'user', '2024-03-08 16:19:10', 100.00, 0.00),
(5, 'Admin_01', '22', 'parinya.pat@rmutto.ac.th', '1234567890', 'Admin_01', '$2y$10$wnF7P0HGyaeRfKvheZoc1OxBt4JKOhW5.31LX27/.eF7nq6CI4Kua', 'ธนาคารกสิกรไทย', '1234567890', 'admin', '2024-03-08 18:37:09', 0.00, 0.00),
(6, 'cheeptana', '21', 'cheaptana.yen@rmutto.ac.th', '0902622420', 'tjz', '$2y$10$DUzSjtH8w2XM9vTnQ6ur6emCNXyN3jLSB9QsMr9a5WtzgACYEE0Hm', 'ธนาคารกรุงเทพ', '1129700247900', 'user', '2024-03-09 23:25:12', 0.00, 0.00),
(10, 'User_02', '45', 'cram@gmail.com', '0847591270', 'User_02', '$2y$10$eSAsN.zkvys6f1mOKH.Lteoc/aCqTl4vwmK7I.TWvSnXxfhMWwLZy', 'ธนาคารกรุงเทพ', '1234567890', 'user', '2024-03-10 13:09:01', 200.00, 0.00),
(11, 'kit39644', '50', 'kit@gmail.com', '0902622420', 'kit23976@gmail.com', '$2y$10$B8TEPsxHviXkHGPu7cWBru4lhejpxz.P6Ak1xTxYcHzl4FpdkoT9e', 'ธนาคารกสิกรไทย', '000000000000', 'user', '2024-03-11 15:05:29', 0.00, 0.00),
(12, 'aaaaaaa', '50', 'kit23976@gmail.com', '0902622420', 'kit23976@gmail.com', '$2y$10$tvtQjedFoYiWA.u00fGQLeyCOzgqR/0NhqW3ZmDJiwY7nQJHmLOIK', 'ธนาคารกรุงเทพ', '45667895648', 'user', '2024-03-11 15:06:26', 0.00, 0.00),
(13, 'wdwd', '22', 'dhhhs@gmail.com', '06634475224', 'dhhhs@gmail.com', '$2y$10$7lNw05z0jtYUZNVljcBqwONU4G8yS8oCvKsySy4yi8cEbTWgI11sy', 'ธนาคารกสิกรไทย', '16412565568745', 'user', '2024-03-11 15:11:33', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `user_topup`
--

CREATE TABLE `user_topup` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_img` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_bank` varchar(255) NOT NULL,
  `user_bank_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user_topup`
--

INSERT INTO `user_topup` (`id`, `user_id`, `user_img`, `price`, `datetime`, `user_bank`, `user_bank_number`) VALUES
(26, '10', '72581882020240311_232508.jpg', 200.00, '2024-03-11 22:25:08', 'ธนาคารกรุงเทพ', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_game`
--
ALTER TABLE `order_game`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topup`
--
ALTER TABLE `topup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `topup_ibfk_1` (`id_order`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_topup`
--
ALTER TABLE `user_topup`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_game`
--
ALTER TABLE `order_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `topup`
--
ALTER TABLE `topup`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_topup`
--
ALTER TABLE `user_topup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
