<?php
session_start();
require_once 'server/server.php';

try {
    // Fetch user data based on the provided ID
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle database error gracefully (consider redirecting to an error page)
    echo "Error fetching user data: " . $e->getMessage();
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Keep track of post values
    $id = $_POST['id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    // Validate passwords
    if (empty($password) || strlen($password) > 20 || strlen($password) < 5 || $password != $password2) {
        // Handle password validation failure appropriately
        echo "Password validation failed";
        exit;
    }

    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Set PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Use placeholders in the UPDATE query
        $stmt = "UPDATE users SET name=?, age=?, phone=?, username=?, password=? WHERE id=?";
        $row = $conn->prepare($stmt);
        $row->execute([$name, $age, $phone, $username, $passwordHash, $id]);

        // Redirect after successful update
        header("Location: user_profile.php");
        exit;
    } catch (PDOException $e) {
        // Handle database error gracefully (consider redirecting to an error page)
        echo "Error updating user data: " . $e->getMessage();
        exit;
    }
}
?>
