<?php
    session_start();
    require_once 'server/server.php';

    if (isset($_POST['sing_in'])){
        $email = $_POST['email'];
        $password =$_POST['password'];

        if (empty($email)){
            $_SESSION['error'] = 'กรุณากรอกอีเมล';
            header("location:index.php");
        } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $_SESSION['error'] = 'รูปแบบอีเมลไม่ถูกต้อง';
            header("location:index.php");
        } else if(empty($password)){
            $_SESSION['error'] = 'กรุณากรอก password';
            header("location:index.php");
        } else if(strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5){
            $_SESSION['error'] = 'รหัสผ่านต้องมีความยาวระหว่าง 5-20 ตัวอักษร';
            header("location:index.php");
        } else {
            try {
                $check_data = $conn->prepare("SELECT id, email, password, urole FROM users WHERE email = :email");
                $check_data->bindParam(":email", $email);
                $check_data->execute();
                $row = $check_data->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    if (password_verify($password, $row['password'])) {
                        if ($row['urole'] == 'admin') {
                            $_SESSION['admin_login'] = $row['id'];
                            header("location: admin_login.php");
                        } else {
                            $_SESSION['user_login'] = $row['id'];
                            header("location: user_dash.php");
                        }
                    } else {
                        $_SESSION['error'] = 'รหัสผ่านผิด';
                        header("location: index.php");
                    }
                } else {
                    $_SESSION['error'] = 'อีเมลผิด';
                    header("location: index.php");
                }
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
    }
?>
