<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Head</title>
    <meta name="author" content="PPC Room the Creator">
    <meta name="keywords" content="Javascript Library & JSON">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/font.css">
</head>
<body>
    <div tabindex="-1" role="dialog" id="modalSignin">
        <div class="modal-dialog" role="document">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header p-5 pb-4 border-bottom-0">
                    <h1 class="fw-bold mb-0 fs-2">เข้าสู่ระบบ</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-5 pt-0">
                    <form action="admin_singin_db.php" method="POST"target="_blank">
                    <?php if(isset($_SESSION['error'])) { ?>
                <div class="alert alert-danger"role="alert">
                    <?php
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                    </div>
            <?php } ?>
            <?php if(isset($_SESSION['success'])) { ?>
            <div class="alert alert-success"role="alert">
                    <?php
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                    </div>
            <?php } ?>
                        
                        <div class="form-floating mb-3">
                        <!--<input type="admin_name" class="form-control rounded-3" name="admin_name" placeholder="name@example.com">
                            <label for="admin_name">admin_name</label>-->
                            <input type="text" class="form-control rounded-3" name="admin_name" placeholder="NAME">
                            <label for="admin_name">Admin Name:</label>
                        </div>
                        
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control rounded-3" name="password" placeholder="Password">
                            <label for="password">Password:</label>
                        </div>
                        <button class="w-100 mb-2 btn btn-lg rounded-3 btn-primary" name="admin_sing_in" type="submit">Login</button>
                        </form>
                        <a class="w-100 mb-2 btn btn-lg rounded-3 btn-primary" href="admin_form.php" style="text-decoration: none; color:rgb(255, 255, 255);"> Sign up</a>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Import Bootstrap JavaScript and jQuery from CDN -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
