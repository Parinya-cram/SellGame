<?php
session_start();
require_once 'server/server.php';

if (!isset($_SESSION['user_login'])) {
    header("location: index.php");
    exit;
}

if (isset($_SESSION['user_login'])) {
    $user_id = $_SESSION['user_login'];
    $stmt = $conn->query("SELECT * FROM users where id = $user_id");
    $result = $stmt->fetch();
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}
$stmt = $conn->query("SELECT u.user_price, SUM(t.price) AS total_price
                      FROM users u
                        JOIN user_topup t ON u.bank_number = t.user_bank_number
                      GROUP BY u.id");
$stmt->execute();
$t = $stmt->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>head</title>
    <meta name="author" content="PPC Room the Creater">
    <meta name="keywords" content="Javascript Library & JSON">
    <meta name="author" content="PPC Room the Creator">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,450;0,180;0,300;0,400;0,450;0,600;0,700;0,800;1,450;1,180;1,300;1,400;1,450;1,600;1,700;1,800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="./css/font.css">
    <link rel="stylesheet" type="text/css" href="bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="jquery/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .background {
            /* ตั้งภาพพื้นหลัง */
            background-image: url('images/bg1.jpg ');
            
            /* ปรับขนาดของภาพให้เต็มหน้าจอ */
            background-size: cover;

            /* ไม่แสดงการเลื่อนหน้าจอ */
            overflow: hidden;
        }

        /* เพิ่มความกำกับในที่ของคุณ */
        .content {
            text-align: center;
            padding: 45px;
            color: white;
        }
    </style>
</head>
<?php include 'head_user.php'; ?>
   
        <div style="background-color: rgb(0, 44, 110);">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="user_dash.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        <span class="fs-4" style="color:rgb(255, 255, 255);"><img src="./images/logo.png" style="height:48px;white:100%;"></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="user_dash.php" class="nav-link " style="color:rgb(255, 255, 255); font-size:20px;">หน้าหลัก</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เกี่ยวกับเรา</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">เติมเกมส์ออนไลน์</a></li>
        <li class="nav-item"><a href="#" class="nav-link" style="color:rgb(255, 255, 255);font-size:20px;">คำถามที่พบบ่อย</a></li>
      </ul>
    </header>
  </div>
    </header>
    <div class="background">
    <div class="container">
    
    <body>
    <div class="modal-content rounded-5 shadow">
		  <div id="myCard" class="card m-4" style="max-width: 100%;">
          <h1 class="k2d-semibold-italic"style="text-align: center;">เติมเครดิต</h1>  
		  <form action="user_topup_db.php" method="post" enctype="multipart/form-data">
        <?php 
        $stmt = $conn->query("SELECT * FROM topup where urlo = 'admin'");
        $result = $stmt->fetch();
        $stmt->execute();
        $a = $stmt->fetch(PDO::FETCH_ASSOC);
        ?>
                    <table class="table table-striped  table-hover table-responsive table-bordered">
                    <div style="text-align: center;">
                            <img src="./images/<?= $a['image'];?>" width="25%">
                            <p><b>หมายเลขบัญชี</b></p>
                            <p><b><?=$a['admin_bank_number'];?></b></p>
                            <p><b><?=$a['admin_bank'];?></b></p>
                            <p><b style="color:red;">*โปรดใช้บัญชีที่ทำการสมัคร ในการเติมเครดิต*</b></p>
                          <label for="user_id"class="form-label">*ID*</label>
                        <input type="number" name="user_id" required class="form-control" placeholder=""value="<?php echo $user_id; ?>"readonly> <br>
                        <label for="user_bank"class="form-label">*ธนาคาร*</label>
                        <input type="text" name="user_bank" required class="form-control" placeholder=""value="<?php echo $row['bank']; ?>"readonly> <br>
                        <label for="user_bank_number"class="form-label">*หมายเลขบัญชี*</label>
                        <input type="number" name="user_bank_number" required class="form-control" placeholder=""value="<?php echo $row['bank_number']; ?>"readonly> <br>
                         <b style="color:red;">*สลิป*</b>
                        <input type="file" name="user_img" required   class="form-control" accept="image/jpeg, image/png, image/jpg"> <br></div>
                            </tbody>
                            <button type="submit" class="btn btn-primary">Upload</button>
            <a href="index.php" class="m-2 p-2 btn btn-success"><i class="bi bi-arrow-left-circle-fill"></i>Back</a>
		  </div>
		  <div>
		  </div>
		  </form>
          </div>
</div>
</div>
</html>