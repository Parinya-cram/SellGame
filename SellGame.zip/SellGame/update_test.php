<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>ฟอร์มอัปเดตราคา</title>
</head>
<body>
  <h1>ฟอร์มอัปเดตราคา</h1>
  <form action="update_test.php" method="post">
    <label for="product_name">ชื่อสินค้า:</label>
    <input type="text" id="product_name" name="product_name">
    <br>
    <label for="new_price">ราคาใหม่:</label>
    <input type="number" id="new_price" name="new_price">
    <br>
    <input type="submit" value="อัปเดต">
  </form>
</body>
</html>
<?php

// เชื่อมต่อกับฐานข้อมูล
$db = new PDO('mysql:host=localhost;dbname=test', 'root', '');

// รับข้อมูลจากฟอร์ม
$product_name = $_POST['product_name'];
$new_price = $_POST['new_price'];

// เตรียมคำสั่ง SQL
$stmt = $db->prepare('UPDATE test SET price = :new_price WHERE name = :product_name');

// ผูกค่ากับพารามิเตอร์
$stmt->bindValue(':new_price', $new_price);
$stmt->bindValue(':product_name', $product_name);

// ดำเนินการคำสั่ง SQL
$stmt->execute();

// แจ้งเตือนผู้ใช้
echo "ราคาของ $product_name ได้รับการอัปเดตเป็น $new_price เรียบร้อยแล้ว";

?>
